package com.quantum.marchofents.items;


import net.minecraft.item.ItemSword;

public class ItemArnorLongsword extends ItemSword {
	public ItemArnorLongsword(ToolMaterial material) {
		super(material);
	}
	

}
