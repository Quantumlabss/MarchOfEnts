package com.quantum.marchofents.init;

import com.quantum.marchofents.MarchOfEnts;
import com.quantum.marchofents.items.ItemArnorLongsword;
import com.quantum.marchofents.items.ItemNargothrondLongsword;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;
import net.minecraftforge.common.util.EnumHelper;

public class Items {
	
	
	//items
	public static Item arnorianLongsword;
	public static Item nargothrondLongsword;
	
	
	//tool materials
	public static final Item.ToolMaterial longswordMaterial = EnumHelper.addToolMaterial("longswordToolMaterial", 4, 2000, 20.0F, 5.0F, 30);
	
	
	
	public static void init()
	{

		//item init
		arnorianLongsword = new ItemArnorLongsword(longswordMaterial).setUnlocalizedName("ItemArnorLongsword").setTextureName("marchofents:dunedain_sword").setCreativeTab(MarchOfEnts.tabMarchOfEnts);
		nargothrondLongsword = new ItemNargothrondLongsword(longswordMaterial).setUnlocalizedName("ItemNargothrondLongsword").setTextureName("marchofents:nargothrond_sword").setCreativeTab(MarchOfEnts.tabMarchOfEnts);
		
		
		
		//Item Register
		GameRegistry.registerItem(arnorianLongsword, arnorianLongsword.getUnlocalizedName().substring(5));
		GameRegistry.registerItem(nargothrondLongsword, nargothrondLongsword.getUnlocalizedName().substring(5));
		
		
	}

}
