package com.quantum.marchofents.items;

import net.minecraft.item.ItemSword;

public class ItemNargothrondLongsword extends ItemSword {
	
	public ItemNargothrondLongsword(ToolMaterial material) {
		super(material);
	}

}
